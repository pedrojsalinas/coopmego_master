<?php
/**
 * @file
 * The whole footer-sitemap container.
 */
?>
<div id="footer-sitemap" class="clearfix">
  <div class="fs-block-content"><?php print render($site_map); ?></div>
</div>
